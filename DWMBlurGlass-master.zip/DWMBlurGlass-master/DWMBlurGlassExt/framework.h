﻿#pragma once

#define WIN32_LEAN_AND_MEAN             // 从 Windows 头文件中排除极少使用的内容
#include <Windows.h>
// Windows 头文件
#include <functional>
#include <string>

#include <Common.h>
#include <VersionHelper.h>
#include <string>
#include <atomic>
#include <array>
#include <format>