﻿#pragma once

#define RESULT_DIAGNOSTICS_LEVEL 0
#include "wil/wrl.h"
#include "wil/common.h"
#include "wil/cppwinrt.h"
#include "wil/filesystem.h"
#include "wil/win32_helpers.h"
#include "wil/result.h"
#include "wil/registry.h"
#include "wil/resource.h"
#include "wil/stl.h"
#include "wil/safecast.h"
#include "wil/com.h"