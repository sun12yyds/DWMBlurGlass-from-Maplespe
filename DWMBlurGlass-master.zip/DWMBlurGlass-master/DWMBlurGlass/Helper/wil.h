﻿#pragma once
#include "wil/wrl.h"
#include "wil/common.h"
#include "wil/cppwinrt.h"
#include "wil/filesystem.h"
#include "wil/result.h"
#include "wil/registry.h"
#include "wil/resource.h"
#include "wil/stl.h"
#include "wil/safecast.h"
#include "wil/com.h"
#define HINST_THISCOMPONENT ((HINSTANCE)&::__ImageBase)