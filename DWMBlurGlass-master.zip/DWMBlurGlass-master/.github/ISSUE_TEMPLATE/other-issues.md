---
name: Other issues
about: Other issues that are not related to feature requests or bug feedback.
title: ''
labels: ''
assignees: ''

---

<!--
If you have other suggestions and requests including discussions, you should go to the discussions page. It is not recommended to create new blank questions here.
-->
